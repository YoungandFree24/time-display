from django.apps import AppConfig


class Template2AppConfig(AppConfig):
    name = 'template2_app'
